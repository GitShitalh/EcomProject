//const orders = require('../models/orders');
const Order= require('../models/orders');

exports.order_create = function (req, res) {
// Validate request
    Order.findOne({order_id: req.body.order_id}).exec((err,order) =>{
        if (err) {
            res.status(500).send({ message: err });
            return;
          }
          if (order) {
            res.status(400).send({ message: "Failed! Order is already exist!" });
            return;
          }
        })
      let order = new Order(
        {
            order_id: req.body.order_id,
            item_name:req.body.item_name,
            cost:req.body.cost,
            order_date:req.body.order_date,
            delivery_date:req.body.delivery_date
            
        }
    );
    order.save(order)
    .then(data => {
      res.status(200).send({data, message:"order created successfully"});
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating Order."
      });
    });
};


// Update a Order by the id in the request
exports.order_update = (req, res) => {
    if (!req.body) {
      return res.status(400).send({
        message: "Data to update can not be empty!"
      });
    }
    const id = req.params.id;
    Order.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
      .then(data => {
        if (!data) {
          res.status(404).send({
            message: `Cannot update Order with id=${id}. Maybe Order was not Created!`
          });
        } else res.status(200).send({message: "Order was updated successfully." });
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating Order with id=" + id
        });
      });
  };

  // Retrieve all Orders from the database.
exports.findAll_order = (req, res) => {
   Order.find()
      .then(data => {
        res.status(200).send({data, message:"Order list"});
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving Orders."
        });
      });
  };


  // Find a single Order with an id
exports.findOne_order = (req, res) => {
    const id = req.params.id;
  
    Order.findById(id)
      .then(data => {
        if (!data)
          res.status(404).send({ message: "Not found Order with id " + id });
        else res.send(data);
      })
      .catch(err => {
        res
          .status(500)
          .send({ message: "Error retrieving Order with id=" + id });
      });
  };


  // Delete a Order with the specified id in the request
exports.delete_order = (req, res) => {
    const id = req.params.id;
  
    Order.findByIdAndRemove(id, { useFindAndModify: false })
      .then(data => {
        if (!data) {
          res.status(404).send({
            message: `Cannot delete Order with id=${id}. Maybe Order was not found!`
          });
        } else {
          res.status(200).send({
            message: "Order was deleted successfully!"
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete order with id=" + id
        });
      });
  };