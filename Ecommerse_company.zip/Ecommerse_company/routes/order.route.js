const express = require('express');
const router = express.Router();
const order_controller = require ('../controllers/order.controllers');

router.post('/create', order_controller.order_create);
router.put('/update/:id', order_controller.order_update);
router.get('/list', order_controller.findAll_order);
router.get('/search/:id',order_controller.findOne_order)
router.delete('/delete/:id',order_controller.delete_order)

module.exports = router;