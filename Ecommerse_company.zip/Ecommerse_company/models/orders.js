const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let OrderSchema = new Schema({
    order_id:{type: Number},
    item_name:{type:String},
    cost:{type: Number},
    order_date:{type:Date},
    delivery_date:{type:Date}
});

//Export the model
module.exports = mongoose.model('Order', OrderSchema);
