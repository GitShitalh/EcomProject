const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/OrdersDB', { useNewUrlParser: true }, (err) => {
    if (!err) { console.log('MongoDB Connection Succeeded.') }
    else { console.log('Error in DB connection : ' + err) }
});
const express = require('express')
const order = require('./routes/order.route'); //imports routes
const app = express()
const port = 3000
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/orders',order);


app.listen(port, () => {
    console.log('Server is up and running on port number ' + port);
});